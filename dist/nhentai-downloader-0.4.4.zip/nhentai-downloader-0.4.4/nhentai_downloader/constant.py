import os


urls = {
    'LOGIN_URL' : 'https://nhentai.net/login/',
    'FAV_URL' : 'https://nhentai.net/favorites/',
    'API_URL' : 'https://nhentai.net/api/gallery/',
    'MEDIA_URL' : 'https://i.nhentai.net/galleries/',
    'SEARCH' : 'https://nhentai.net/search/?q='
}
