__version__ = '0.4.4'
__author__ = 'DukeValentine'
__email__ = 'humanix@posteo.de'
