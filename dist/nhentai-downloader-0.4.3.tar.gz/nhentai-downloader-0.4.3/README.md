# Nhentai downloader

Python command line program to retrieve information from and download nhentai galleries. 